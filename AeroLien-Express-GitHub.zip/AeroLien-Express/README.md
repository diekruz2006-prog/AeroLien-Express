# AéroLien Express

Covoiturage express entre Gatineau/Ottawa, Montréal (YUL) et Québec (YQB).

- **Passager :** abonnement 5 $/an (1 crédit de bienvenue), 1 crédit (5 $) par réservation ou colis.
- **Chauffeur :** abonnement 5 $/an, publication des trajets **gratuite**.
- Le siège se paie directement au chauffeur.

## Trajets
Toutes les combinaisons aéroport ↔ ville (YOW, YUL, YQB × Gatineau, Ottawa, Montréal, Québec), dans les deux sens, plus aéroport ↔ aéroport : 30 trajets possibles, avec un prix suggéré modifiable.

## Langues
Le site est offert en français et en anglais (boutons FR / EN dans l’en-tête; le choix est mémorisé).

## Structure
- `site/` : le site (HTML/JS, sans compilation). Modifiez `site/config.js`.
- `supabase/schema.sql` : base de données et règles.
- `supabase/functions/` : paiements Stripe.
- `GUIDE.md` : installation complète pas à pas.

## Déployer sur Netlify depuis GitHub
1. Poussez ce dépôt sur GitHub (nom suggéré : `AeroLien-Express`).
2. Netlify > Add new site > Import from Git > choisissez le dépôt. `netlify.toml` indique déjà le dossier `site`.
3. Sans GitHub : glissez le dossier `site` (ou `AeroLien-Express-Netlify.zip`) sur app.netlify.com/drop.
