-- AéroLien Express : base de données Supabase (à coller dans SQL Editor)
-- Compte unique passager/chauffeur, abonnement 5 $/an + 1 crédit de bienvenue, crédits de 5 $
create table profiles(
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'passenger' check (role in ('passenger','driver')),
  name text not null, email text not null, phone text not null default '',
  license text, car text, plate text,
  car_type text not null default 'gas' check (car_type in ('gas','hybrid','electric')),
  member_until date,
  credits int not null default 0 check (credits >= 0),
  created_at timestamptz not null default now());

create table rides(
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references profiles on delete cascade,
  driver_name text not null, car text,
  eco boolean not null default false, accepts_parcels boolean not null default false,
  origin text not null check (origin in ('GAT','OTT','MTL','QC','YOW','YUL','YQB')),
  destination text not null check (destination in ('GAT','OTT','MTL','QC','YOW','YUL','YQB')),
  check (origin <> destination and (origin in ('YOW','YUL','YQB') or destination in ('YOW','YUL','YQB'))),
  from_place text not null, to_place text not null,
  depart_date date not null, depart_time time not null,
  price int not null, seats int not null, bag text,
  created_at timestamptz not null default now());

create table bookings(
  id uuid primary key default gen_random_uuid(),
  ride_id uuid references rides on delete set null,
  passenger_id uuid not null references profiles on delete cascade,
  driver_id uuid not null,
  from_place text, to_place text, depart_date date, depart_time time, price int,
  driver_name text, driver_phone text, car text, flight text, pay text,
  pin text not null,
  status text not null default 'confirmed' check (status in ('confirmed','completed','cancelled','late_cancelled')),
  created_at timestamptz not null default now());

create table parcels(
  id uuid primary key default gen_random_uuid(),
  ride_id uuid references rides on delete set null,
  sender_id uuid not null references profiles on delete cascade,
  driver_id uuid not null,
  sender_name text, sender_phone text, driver_name text, driver_phone text,
  from_place text, to_place text, depart_date date,
  description text not null, size text not null,
  created_at timestamptz not null default now());

create table credit_ledger(
  id bigserial primary key,
  user_id uuid not null references profiles on delete cascade,
  delta int not null, reason text not null,
  stripe_session_id text unique,
  created_at timestamptz not null default now());

-- Sécurité : lecture seulement; toute écriture passe par les fonctions ci-dessous
alter table profiles enable row level security;
alter table rides enable row level security;
alter table bookings enable row level security;
alter table parcels enable row level security;
alter table credit_ledger enable row level security;
create policy "profil: lecture perso" on profiles for select to authenticated using (id = auth.uid());
create policy "profil: modif perso" on profiles for update to authenticated using (id = auth.uid());
create policy "trajets: lecture" on rides for select to authenticated using (true);
create policy "reservations: lecture passager" on bookings for select to authenticated using (passenger_id = auth.uid());
create policy "colis: expediteur ou chauffeur" on parcels for select to authenticated using (sender_id = auth.uid() or driver_id = auth.uid());
create policy "registre: lecture perso" on credit_ledger for select to authenticated using (user_id = auth.uid());
revoke insert, update, delete on profiles, rides, bookings, parcels, credit_ledger from anon, authenticated;
grant update (name, phone, license, car, plate, car_type) on profiles to authenticated;

-- Création automatique du compte à l'inscription (toujours en mode passager)
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, name, email, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'name','Sans nom'), new.email, coalesce(new.raw_user_meta_data->>'phone',''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Bascule passager <-> chauffeur (chauffeur : permis, véhicule et plaque obligatoires)
create function set_role(p_role text) returns void language plpgsql security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'Non connecté'; end if;
  if p_role not in ('passenger','driver') then raise exception 'Rôle invalide'; end if;
  if p_role = 'driver' and (coalesce(me.license,'') = '' or coalesce(me.car,'') = '' or coalesce(me.plate,'') = '') then
    raise exception 'Permis, véhicule et plaque obligatoires pour le mode chauffeur';
  end if;
  update profiles set role = p_role where id = me.id;
end $$;

-- Publier un trajet : gratuit (mode chauffeur, abonnement actif)
create function publish_ride(p_origin text, p_destination text, p_from text, p_to text, p_date date, p_time time, p_price int, p_seats int, p_bag text, p_parcels boolean)
returns uuid language plpgsql security definer set search_path = public as $$
declare me profiles; rid uuid;
begin
  select * into me from profiles where id = auth.uid() for update;
  if me.id is null or me.role <> 'driver' then raise exception 'Réservé au mode chauffeur'; end if;
  if me.member_until is null or me.member_until < current_date then raise exception 'Abonnement expiré'; end if;
  if p_date < current_date then raise exception 'Date passée'; end if;
  if p_origin = p_destination or not (p_origin in ('YOW','YUL','YQB') or p_destination in ('YOW','YUL','YQB')) then raise exception 'Le trajet doit relier un aéroport à une ville ou à un autre aéroport'; end if;
  if p_seats < 1 or p_seats > 6 or p_price < 5 or p_price > 200 then raise exception 'Valeurs invalides'; end if;
  insert into rides(driver_id, driver_name, car, eco, accepts_parcels, origin, destination, from_place, to_place, depart_date, depart_time, price, seats, bag)
  values (me.id, me.name, trim(coalesce(me.car,'') || ' ' || coalesce(me.plate,'')), me.car_type in ('hybrid','electric'), coalesce(p_parcels,false), p_origin, p_destination, p_from, p_to, p_date, p_time, p_price, p_seats, p_bag)
  returning id into rid;
  return rid;
end $$;

-- Réserver une place : 1 crédit (mode passager), code de confirmation à 4 chiffres
create function book_ride(p_ride uuid, p_flight text, p_pay text)
returns json language plpgsql security definer set search_path = public as $$
declare me profiles; r rides; d profiles; v_pin text;
begin
  select * into me from profiles where id = auth.uid() for update;
  if me.id is null or me.role <> 'passenger' then raise exception 'Réservé au mode passager'; end if;
  if me.member_until is null or me.member_until < current_date then raise exception 'Abonnement expiré'; end if;
  if me.credits < 1 then raise exception 'Crédits insuffisants'; end if;
  if p_pay <> 'cash' then raise exception 'Mode de paiement invalide'; end if;
  select * into r from rides where id = p_ride for update;
  if r.id is null or r.seats < 1 then raise exception 'Trajet complet'; end if;
  if r.depart_date < current_date then raise exception 'Trajet passé'; end if;
  if r.driver_id = me.id then raise exception 'Vous ne pouvez pas réserver votre propre trajet'; end if;
  if exists (select 1 from bookings where ride_id = r.id and passenger_id = me.id and status = 'confirmed') then
    raise exception 'Vous avez déjà réservé ce trajet';
  end if;
  select * into d from profiles where id = r.driver_id;
  v_pin := lpad((floor(random() * 10000))::int::text, 4, '0');
  update rides set seats = seats - 1 where id = r.id;
  update profiles set credits = credits - 1 where id = me.id;
  insert into credit_ledger(user_id, delta, reason) values (me.id, -1, 'reservation');
  insert into bookings(ride_id, passenger_id, driver_id, from_place, to_place, depart_date, depart_time, price, driver_name, driver_phone, car, flight, pay, pin)
  values (r.id, me.id, r.driver_id, r.from_place, r.to_place, r.depart_date, r.depart_time, r.price, d.name, d.phone, r.car, p_flight, p_pay, v_pin);
  return json_build_object('driver_name', d.name, 'driver_phone', d.phone, 'car', r.car, 'pin', v_pin);
end $$;

-- Annulation : sans frais jusqu'à 24 h avant le départ, sinon le crédit est retenu
create function cancel_booking(p_booking uuid) returns json language plpgsql security definer set search_path = public as $$
declare b bookings; departs timestamptz;
begin
  select * into b from bookings where id = p_booking and passenger_id = auth.uid() for update;
  if b.id is null then raise exception 'Réservation introuvable'; end if;
  if b.status <> 'confirmed' then raise exception 'Réservation déjà traitée'; end if;
  departs := (b.depart_date + b.depart_time) at time zone 'America/Toronto';
  if b.ride_id is not null then update rides set seats = seats + 1 where id = b.ride_id; end if;
  if departs - now() >= interval '24 hours' then
    update bookings set status = 'cancelled' where id = b.id;
    update profiles set credits = credits + 1 where id = b.passenger_id;
    insert into credit_ledger(user_id, delta, reason) values (b.passenger_id, 1, 'annulation plus de 24 h');
    return json_build_object('refunded', true);
  end if;
  update bookings set status = 'late_cancelled' where id = b.id;
  return json_build_object('refunded', false);
end $$;

-- Le chauffeur confirme le trajet avec le code du passager
create function complete_booking(p_booking uuid, p_pin text) returns void language plpgsql security definer set search_path = public as $$
declare b bookings;
begin
  select * into b from bookings where id = p_booking and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'Réservation introuvable'; end if;
  if b.status <> 'confirmed' then raise exception 'Réservation déjà traitée'; end if;
  if b.pin <> p_pin then raise exception 'Code incorrect'; end if;
  update bookings set status = 'completed' where id = b.id;
end $$;

-- Liste des passagers du chauffeur (sans le code de confirmation)
create function driver_roster()
returns table (id uuid, from_place text, to_place text, depart_date date, depart_time time, passenger_name text, passenger_phone text, flight text, status text)
language sql security definer set search_path = public as $$
  select b.id, b.from_place, b.to_place, b.depart_date, b.depart_time, p.name, p.phone, b.flight, b.status
  from bookings b join profiles p on p.id = b.passenger_id
  where b.driver_id = auth.uid() order by b.depart_date desc, b.depart_time desc;
$$;

-- Envoyer un colis : 1 crédit
create function send_parcel(p_ride uuid, p_desc text, p_size text) returns json language plpgsql security definer set search_path = public as $$
declare me profiles; r rides; d profiles;
begin
  select * into me from profiles where id = auth.uid() for update;
  if me.id is null or me.role <> 'passenger' then raise exception 'Réservé au mode passager'; end if;
  if me.member_until is null or me.member_until < current_date then raise exception 'Abonnement expiré'; end if;
  if me.credits < 1 then raise exception 'Crédits insuffisants'; end if;
  select * into r from rides where id = p_ride;
  if r.id is null or not r.accepts_parcels then raise exception 'Ce trajet n’accepte pas de colis'; end if;
  if r.depart_date < current_date then raise exception 'Trajet passé'; end if;
  if p_size not in ('petit','moyen','grand') or coalesce(p_desc,'') = '' then raise exception 'Informations invalides'; end if;
  select * into d from profiles where id = r.driver_id;
  update profiles set credits = credits - 1 where id = me.id;
  insert into credit_ledger(user_id, delta, reason) values (me.id, -1, 'colis');
  insert into parcels(ride_id, sender_id, driver_id, sender_name, sender_phone, driver_name, driver_phone, from_place, to_place, depart_date, description, size)
  values (r.id, me.id, r.driver_id, me.name, me.phone, d.name, d.phone, r.from_place, r.to_place, r.depart_date, p_desc, p_size);
  return json_build_object('driver_name', d.name, 'driver_phone', d.phone);
end $$;

-- Appelées seulement par le webhook Stripe (idempotentes)
create function activate_membership(p_user uuid, p_session text) returns void language plpgsql security definer set search_path = public as $$
declare m date;
begin
  insert into credit_ledger(user_id, delta, reason, stripe_session_id) values (p_user, 0, 'abonnement annuel 5 $', p_session) on conflict (stripe_session_id) do nothing;
  if found then
    select member_until into m from profiles where id = p_user;
    if m is null then
      update profiles set credits = credits + 1, member_until = (current_date + interval '1 year')::date where id = p_user;
      insert into credit_ledger(user_id, delta, reason) values (p_user, 1, 'crédit de bienvenue');
    else
      update profiles set member_until = (greatest(m, current_date) + interval '1 year')::date where id = p_user;
    end if;
  end if;
end $$;
create function grant_credits(p_user uuid, p_n int, p_session text) returns void language plpgsql security definer set search_path = public as $$
begin
  insert into credit_ledger(user_id, delta, reason, stripe_session_id) values (p_user, p_n, 'achat de crédits', p_session) on conflict (stripe_session_id) do nothing;
  if found then update profiles set credits = credits + p_n where id = p_user; end if;
end $$;

revoke execute on function activate_membership, grant_credits from public, anon, authenticated;
grant execute on function activate_membership, grant_credits to service_role;
revoke execute on function set_role, publish_ride, book_ride, cancel_booking, complete_booking, driver_roster, send_parcel from public, anon;
grant execute on function set_role, publish_ride, book_ride, cancel_booking, complete_booking, driver_roster, send_parcel to authenticated;
