import Stripe from "https://esm.sh/stripe@16.12.0?target=denonext";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, { apiVersion: "2024-06-20" });
const SITE = Deno.env.get("SITE_URL")!; // ex. https://aerolien.ca
const cors = { "Access-Control-Allow-Origin": SITE, "Access-Control-Allow-Headers": "authorization, apikey, content-type", "Content-Type": "application/json" };
const PACKS: Record<number, number> = { 5: 2500, 10: 4500, 15: 6000 }; // crédits -> cents CAD

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return new Response(JSON.stringify({ error: "Non connecté" }), { status: 401, headers: cors });
  const { kind, credits } = await req.json();

  let name: string, amount: number, metadata: Record<string, string>;
  if (kind === "registration") {
    name = "Abonnement annuel AéroLien Express"; amount = 500; metadata = { kind };
  } else if (kind === "credits" && PACKS[credits]) {
    name = `${credits} crédits AéroLien`; amount = PACKS[credits]; metadata = { kind, credits: String(credits) };
  } else return new Response(JSON.stringify({ error: "Demande invalide" }), { status: 400, headers: cors });

  const session = await stripe.checkout.sessions.create({
    mode: "payment", customer_email: user.email, client_reference_id: user.id, metadata,
    line_items: [{ quantity: 1, price_data: { currency: "cad", unit_amount: amount, product_data: { name } } }],
    success_url: `${SITE}/?paid=1`, cancel_url: `${SITE}/?cancel=1`,
  });
  return new Response(JSON.stringify({ url: session.url }), { headers: cors });
});
