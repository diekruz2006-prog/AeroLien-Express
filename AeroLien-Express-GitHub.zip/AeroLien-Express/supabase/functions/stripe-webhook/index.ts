import Stripe from "https://esm.sh/stripe@16.12.0?target=denonext";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, { apiVersion: "2024-06-20" });
const crypto = Stripe.createSubtleCryptoProvider();

Deno.serve(async (req) => {
  const sig = req.headers.get("stripe-signature") ?? "";
  const body = await req.text();
  let ev: Stripe.Event;
  try {
    ev = await stripe.webhooks.constructEventAsync(body, sig, Deno.env.get("STRIPE_WEBHOOK_SECRET")!, undefined, crypto);
  } catch { return new Response("Signature invalide", { status: 400 }); }

  if (ev.type === "checkout.session.completed") {
    const s = ev.data.object as Stripe.Checkout.Session;
    if (s.payment_status === "paid" && s.client_reference_id) {
      const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
      const kind = s.metadata?.kind;
      const { error } = kind === "registration"
        ? await admin.rpc("activate_membership", { p_user: s.client_reference_id, p_session: s.id })
        : await admin.rpc("grant_credits", { p_user: s.client_reference_id, p_n: Number(s.metadata?.credits), p_session: s.id });
      if (error) return new Response(error.message, { status: 500 }); // Stripe réessaiera
    }
  }
  return new Response("ok");
});
