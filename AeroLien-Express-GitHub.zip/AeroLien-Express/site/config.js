// Configuration publique d'AéroLien Express (Supabase > Project Settings > API)
// La clé "anon public" est faite pour être visible dans le navigateur.
window.AEROLIEN_CONFIG = {
  URL: "https://VOTRE-PROJET.supabase.co",
  KEY: "VOTRE_CLE_ANON_PUBLIQUE"
};
