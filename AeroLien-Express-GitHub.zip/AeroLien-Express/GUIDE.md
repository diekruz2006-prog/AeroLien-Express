# AéroLien Express : mise en ligne avec Supabase et Stripe

Contenu du dossier :
- `supabase/schema.sql` : tables, sécurité, abonnement, crédits (1 crédit par réservation ou par colis; publication de trajets gratuite pour les chauffeurs), annulation, code de confirmation
- `supabase/functions/create-checkout` : crée le paiement Stripe (abonnement annuel de 5 $, forfaits de crédits)
- `supabase/functions/stripe-webhook` : reçoit la confirmation de Stripe et active l’abonnement (avec 1 crédit de bienvenue) ou ajoute les crédits
- `site/index.html` : le site, branché sur Supabase

## 1. Supabase (base de données et comptes)
1. Créez un compte sur supabase.com, puis un projet (choisissez la région Canada Central).
2. Menu SQL Editor : collez tout `supabase/schema.sql` et cliquez sur Run.
3. Menu Project Settings > API : notez l’URL du projet et la clé `anon public`.
4. Menu Authentication > URL Configuration : mettez l’adresse de votre site dans « Site URL » (ex. https://aerolien.ca).

## 2. Stripe (paiements)
1. Créez un compte sur stripe.com (mode test au début). Les montants sont en dollars canadiens (CAD).
2. Notez la clé secrète de test (`sk_test_...`) dans Developers > API keys.

## 3. Déployer les deux fonctions
Installez la CLI Supabase, puis dans le dossier `aerolien-live` :

    supabase login
    supabase link --project-ref VOTRE_REF_PROJET
    supabase secrets set STRIPE_SECRET_KEY=sk_test_xxx SITE_URL=https://aerolien.ca
    supabase functions deploy create-checkout
    supabase functions deploy stripe-webhook --no-verify-jwt

## 4. Webhook Stripe
1. Stripe > Developers > Webhooks > Add endpoint.
2. URL : `https://VOTRE_REF_PROJET.supabase.co/functions/v1/stripe-webhook`
3. Événement : `checkout.session.completed`
4. Copiez le « Signing secret » (`whsec_...`) puis :

       supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_xxx

## 5. Brancher le site
Ouvrez `site/config.js` et remplacez `URL` et `KEY` par l’adresse du projet et la clé `anon public`.
Hébergez ensuite le dossier `site` (Netlify, Vercel ou Cloudflare Pages : glisser-déposer suffit), puis reliez votre nom de domaine.

## 6. Tester avant d’ouvrir
- Créez un compte, payez l’abonnement de 5 $ avec la carte de test `4242 4242 4242 4242` (date future, CVC quelconque).
- Achetez des crédits, passez en mode chauffeur (permis, véhicule, plaque), publiez un trajet, puis repassez en mode passager avec un second compte pour le réserver, l’annuler, puis le confirmer avec le code.
- Vérifiez que le compte reçoit 1 crédit de bienvenue, que la publication d’un trajet ne coûte rien, que les crédits du passager baissent de 1 par réservation et qu’une annulation de plus de 24 h les rembourse.

## 7. Passer en réel
- Dans Stripe, activez votre compte (identité, compte bancaire), puis remplacez les clés `sk_test` et `whsec` par celles du mode réel.
- Faites valider avec un comptable la TPS/TVQ sur l’abonnement de 5 $ et les crédits.
- Faites valider avec un conseiller juridique le cadre du covoiturage rémunéré (permis, assurance, CTQ), et rédigez des conditions d’utilisation et une politique de confidentialité.
- Ajoutez un système d’annulation et de remboursement avant d’accueillir de vrais clients.

## Règles intégrées
- Abonnement : 5 $ par an, 1 crédit de bienvenue seulement à la première inscription. À l’expiration, le compte demande le renouvellement.
- Publication de trajets gratuite pour les chauffeurs (abonnement annuel actif requis).
- Un seul compte : bascule passager/chauffeur, permis, véhicule et plaque obligatoires pour conduire.
- Annulation : crédit remboursé si plus de 24 h avant le départ, retenu sinon.
- Code à 4 chiffres : remis par le passager au chauffeur pour confirmer le trajet. Il ne retient aucun argent, car le siège est payé au chauffeur.
- Colis : 1 crédit, sur les trajets où le chauffeur les accepte. Badge Éco-Route pour les véhicules hybrides et électriques.

## Limites actuelles
- Pas de mot de passe oublié ni de vérification du permis de conduire : à ajouter.
- Le paiement du siège se fait directement au chauffeur seulement.
- Pas de suivi automatique des vols, de notifications SMS (Twilio) ni de calcul d’empreinte carbone.
- Pas encore d’évaluations des chauffeurs ni de messagerie.
